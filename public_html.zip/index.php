<?php
header("Location: diamondshare://open");
exit;
?>